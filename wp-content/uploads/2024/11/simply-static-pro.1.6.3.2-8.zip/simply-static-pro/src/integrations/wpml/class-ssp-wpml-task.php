<?php

namespace simply_static_pro;

use Simply_Static;

/**
 * Class which handles WPML task.
 */
class WPML_Task extends Simply_Static\Task {

	/**
	 * Array of languages.
	 *
	 * @var null|array
	 */
	protected $langs = null;

	/**
	 * Get the WPML langs.
	 *
	 * @return mixed|null
	 */
	public function get_langs() {
		if ( $this->langs === null ) {
			$this->langs = apply_filters( 'wpml_active_languages', [] );
		}

		return $this->langs;
	}

	/**
	 * Get the processed langs.
	 *
	 * @return array|mixed|null
	 */
	public function get_processed_langs() {
		$processed_langs = $this->options->get( 'wpml_processed_languages' );

		if ( ! $processed_langs ) {
			$processed_langs = [];
		}

		return $processed_langs;
	}

	/**
	 * Get the copied langs.
	 *
	 * @return array|mixed|null
	 */
	public function get_copied_langs() {
		$copied_langs = $this->options->get( 'wpml_copied_languages' );

		if ( ! $copied_langs ) {
			$copied_langs = [];
		}

		return $copied_langs;
	}

	public function perform() {

		try {
			$langs_to_process = $this->copy_langs();

			if ( ! $langs_to_process ) {
				$this->options->destroy( 'wpml_copied_languages' );
				$this->options->destroy( 'wpml_processed_languages' );
				$this->options->save();
				return true;
			}

			$files_to_copy   = $this->scan_wp_content();
			$cleaned_files   = $this->remove_archive_path( $files_to_copy );
			$processed_paths = $this->get_processed_files();

			foreach ( $langs_to_process as $lang ) {
				$this->process_lang( $lang, $cleaned_files, $processed_paths );
			}
		} catch ( \Exception $e ) {
			$this->save_status_message( __( 'WPML Error while copying language files:' , 'simply-static-pro' ) . ' ' . $e->getMessage() . __( 'Continuing export without them...', 'simply-static-pro' ) );
			return true; // Returning true so we continue with export.
		}


		return false;
	}

	public function remove_archive_path( $files ) {
		$archive_folder = $this->options->get_archive_dir();

		return array_map( function( $file ) use ( $archive_folder ) {
			return DIRECTORY_SEPARATOR . ltrim( str_replace( $archive_folder, '', $file ), DIRECTORY_SEPARATOR );
		}, $files );
	}

	public function process_lang( $lang, $files, $processed_files ) {
		$processed_paths_for_lang = $this->get_lang_files( $lang, $processed_files );

		if ( count( $processed_paths_for_lang ) >= count( $files ) ) {
			$this->save_lang_as_processed( $lang );
			return;
		}

		$files_to_process = $this->get_files_to_process( $lang, $processed_paths_for_lang, $files );

		if ( ! $files_to_process ) {
			$this->save_lang_as_processed( $lang );
			return;
		}

		$this->insert_files( $files_to_process );

		$this->save_lang_as_processed( $lang );
	}

	public function get_files_to_process( $lang, $processed_files, $all_files ) {
		$prepared_files = array_map( function( $file ) use ( $lang ) {
			return DIRECTORY_SEPARATOR . $lang . DIRECTORY_SEPARATOR . ltrim( $file, DIRECTORY_SEPARATOR );
		}, $all_files );

		$to_process = array_diff( $prepared_files, $processed_files );

		return $to_process;
	}


	public function save_lang_as_processed( $lang ) {
		$processed_langs = $this->get_processed_langs();
		$processed_langs[] = $lang;
		$this->options->set( 'wpml_processed_languages', $processed_langs );
		$this->options->save();

	}

	/**
	 * Copy langs and return langs to process.
	 *
	 * @return array
	 */
	public function copy_langs() {
		global $sitepress;

		$filesystem = Helper::get_file_system();

		if ( ! $filesystem ) {
			return [];
		}

		$default_code      = $sitepress->get_default_language();
		$url_Settings      = $sitepress->get_setting( "urls" );
		$langs             = $this->get_langs();
		$langs_to_process  = [];
		$processed_langs   = $this->get_processed_langs();
		$copied_langs      = $this->get_copied_langs();
		$archive_folder    = rtrim( $this->options->get_archive_dir(), DIRECTORY_SEPARATOR );
		$wp_content_folder = $this->get_wp_content_name();
		$wp_content_dir    = $this->get_wp_content_dir();

		foreach ( $langs as $lang ) {
			// If it's the default language and it's not using a directory as well, skip it.
			if ( $default_code === $lang['code'] && absint( $url_Settings['directory_for_default_language'] ) === 0 ) {
				continue;
			}

			if ( in_array( $lang['code'], $processed_langs, true  ) ) {
				continue;
			}

			$langs_to_process[] = $lang['code'];

			if ( in_array( $lang['code'], $copied_langs, true  ) ) {
				continue;
			}

			$lang_content_dir = $archive_folder . DIRECTORY_SEPARATOR . $lang['code'] . DIRECTORY_SEPARATOR . $wp_content_folder;

			if ( ! is_dir( $lang_content_dir ) ) {
				@mkdir( $lang_content_dir, 0755, true );
			}
			$resp = copy_dir( $wp_content_dir, $lang_content_dir );
			if ( is_wp_error( $resp ) ) {
				throw new \Exception( $resp->get_error_message() );
			}
			$copied_langs[] = $lang['code'];
		}

		$this->options->set( 'wpml_copied_languages', $copied_langs );
		$this->options->save();

		return $langs_to_process;

	}

	/**
	 * Get the files from file paths related to the language.
	 *
	 * @param string   $lang Lang code. Example: en
	 * @param string[] $file_paths Array of file paths.
	 *
	 * @return array
	 */
	public function get_lang_files( $lang, $file_paths ) {
		$content_dir = DIRECTORY_SEPARATOR . $lang . DIRECTORY_SEPARATOR . $this->get_wp_content_name() . DIRECTORY_SEPARATOR;

		return array_filter( $file_paths, function ( $file_path ) use ( $content_dir ) {
			return strpos( $file_path, $content_dir ) === 0;
		});
	}

	/**
	 * Get the WP Content folder name.
	 *
	 * @return mixed|string
	 */
	public function get_wp_content_name() {
		$wp_content_folder     = 'wp-content';
		$content_folder_change = $this->options->get( 'wp_content_directory' );

		if ( $content_folder_change && $content_folder_change !== $wp_content_folder ) {
			$wp_content_folder = $content_folder_change;
		}

		return $wp_content_folder;
	}

	/**
	 * Scan the WP Content.
	 *
	 * @return array|mixed
	 */
	public function scan_wp_content() {
		$content_dir = $this->get_wp_content_dir();
		return $this->scan_dir( $content_dir );
	}

	/**
	 * Get the WP Content dir path.
	 *
	 * @param string $lang Lang code.
	 *
	 * @return string
	 */
	public function get_wp_content_dir( $lang = '' ) {
		$wp_content_folder = $this->get_wp_content_name();
		$archive_folder    = $this->options->get_archive_dir();

		$lang_path = $lang ? $lang . DIRECTORY_SEPARATOR : '';

		return rtrim( $archive_folder, DIRECTORY_SEPARATOR ) . DIRECTORY_SEPARATOR . $lang_path . $wp_content_folder;
	}

	/**
	 * Insert the file paths.
	 *
	 * @param string[] $file_paths File paths.
	 *
	 * @return void
	 */
	public function insert_files( $file_paths ) {
		global $wpdb;
		$chunks = array_chunk( $file_paths, 250 );

		foreach ( $chunks as $chunk ) {
			$values = [];
			foreach ( $chunk as $file ) {
				$values[] = $wpdb->prepare("(%s,%s,'WPML',%s)", $file, home_url( $file ), current_time( 'mysql' ) );
			}
			$wpdb->query( "INSERT INTO {$wpdb->prefix}simply_static_pages (file_path, url, status_message, created_at) VALUES " . implode( ',', $values ) . ";" );
		}
	}

	/**
	 * Get processed files.
	 *
	 * @return array
	 */
	public function get_processed_files() {
		global $wpdb;

		$files = $wpdb->get_results( $wpdb->prepare( "SELECT file_path FROM {$wpdb->prefix}simply_static_pages WHERE status_message=%s", "WPML" ), ARRAY_A );
		return wp_list_pluck( $files, 'file_path' );
	}

	/**
	 * Scan the dir recursively.
	 *
	 * @param string   $dir File path.
	 * @param string[] $files Scanned files.
	 *
	 * @return array|mixed
	 */
	public function scan_dir( $dir, $files = [] ) {
		if ( is_dir( $dir ) ) {
			$content = scandir( $dir );

			foreach ( $content as $item ) {
				if ( in_array( $item, [ '.', '..' ], true  ) ) {
					continue;
				}

				$path = rtrim( $dir, DIRECTORY_SEPARATOR ) . DIRECTORY_SEPARATOR . $item;

				if ( is_dir( $path ) ) {
					$files = $this->scan_dir( $path, $files );
					continue;
				}

				if ( is_file( $path ) ) {
					$files[] = $path;
				}
			}
		}

		return $files;
	}
}