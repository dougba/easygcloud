<?php

namespace simply_static_pro;


use Exception;
use Simply_Static;
use Simply_Static\Options;
use Simply_Static\Page;
use Simply_Static\Util;

/**
 * Class which handles GitHub commits.
 */
class Github_Blobs_Task extends Simply_Static\Task {

	use Simply_Static\canProcessPages;
	use Simply_Static\canTransfer;

	/**
	 * The task name.
	 *
	 * @var string
	 */
	protected static $task_name = 'github_blobs';

	/**
	 * Temp directory.
	 *
	 * @var string
	 */
	private string $temp_dir;

	/**
	 * Github db class.
	 *
	 * @var null|\simply_static_pro\Github_Database
	 */
	protected $database = null;

	/**
	 * GitHub Rate Limits
	 * @var null
	 */
	protected $rate_limits = null;

	/**
	 * Flag if this is the first iteration of this task for the current export.
	 *
	 * @var bool
	 */
	protected $first_iteration = false;

	/**
	 * Constructor
	 */
	public function __construct() {
		parent::__construct();

		$options        = Options::instance();
		$this->options  = $options;
		$this->temp_dir = $options->get_archive_dir();
	}

	/**
	 * Set Start Time
	 *
	 * @return void
	 */
	public function set_start_time() {
		$start_time = get_option( 'ssp_github_blob_start_time' );

		if ( ! $start_time ) {
			$this->first_iteration = true;
			$start_time            = Util::formatted_datetime();
			update_option('ssp_github_blob_start_time', $start_time);
		}

		$this->start_time = $start_time;
	}

	/**
	 * @return array|null
	 */
	protected function get_rate_limits() {
		if ( null === $this->rate_limits ) {
			$database          = $this->get_database();
			$this->rate_limits = $database->get_rate_limits();
		}

		return $this->rate_limits;
	}

	/**
	 * Return the Github Database.
	 *
	 * @return object|\simply_static_pro\Github_Database|null
	 */
	protected function get_database() {
		if ( null === $this->database ) {
			$this->database = \simply_static_pro\Github_Database::get_instance();
		}

		return $this->database;
	}

	/**
	 * Message to set when processed pages.
	 *
	 * @param integer $processed Number of pages processed.
	 * @param integer $total Number of total pages to process.
	 *
	 * @return string
	 */
	protected function processed_pages_message( $processed, $total ) {
		return sprintf( __( "Prepared %d of %d files for committing to GitHub.", 'simply-static' ), $processed, $total );
	}

	/**
	 * Maybe clear the repo if it's set to be cleared.
	 * Runs only once per export.
	 *
	 * @return void
	 */
	protected function maybe_clear_repository() {

		// Check to clear repo only on the first iteration for the current export.
		if ( ! $this->first_iteration ) {
			return;
		}

		$repository       = \simply_static_pro\Github_Repository::get_instance();
		$clear_repository = apply_filters( 'ssp_clear_repository', false );

		if ( $clear_repository ) {
			// Check if it's a full static export.
			$use_single = get_option( 'simply-static-use-single' );
			$use_build  = get_option( 'simply-static-use-build' );

			if ( ! isset( $use_build ) && ! isset( $use_single ) ) {
				$repository->delete_repository();
				$repository->add_repository();
				$repository->add_file( 'simply-static.txt', 'This file was created by Simply Static Pro.', __( 'Added the sample file.', 'simply-static-pro' ) );
			}
		}
	}

	/**
	 * Push a batch of files from the temp dir to GitHub.
	 *
	 * @return boolean true if done, false if not done.
	 * @throws Exception When the GitHub API returns an error.
	 */
	public function perform(): bool {
		$this->maybe_clear_repository();

		// Prepare GitHub Database API.
		$this->database = $this->get_database();

		$done = $this->process_pages();

		// Handle rate limits.
		$rate_limit      = $this->get_rate_limits();
		$should_sleep    = get_option( 'ssp_github_should_sleep' );
		$remaining_pages = count( $this->get_pages_to_process() );

		if ( intval( $rate_limit['remaining'] ) < $remaining_pages && false === $should_sleep ) {
			// Calculate time to wait.
			$now     = time();
			$seconds = ( intval( $rate_limit['reset'] ) - $now );

			update_option( 'ssp_github_should_sleep', true );

			Util::debug_log( 'You exceeded the GitHub API rate limit. We need to wait for ' . $seconds . ' seconds.' );
			sleep( $seconds );
		}

		if ( false !== $should_sleep ) {
			$now     = time();
			$seconds = ( intval( $rate_limit['reset'] ) - $now );

			Util::debug_log( 'We are still waiting for the GitHub API rate limit to reset. We need to wait for ' . $seconds . '. seconds.' );
			sleep( $seconds );
		}

		if ( ! $done ) {
			return $done;
		}

		// return true when done (no more pages).
		if ( ! empty( $blobs ) ) {
			// Handle cleanup.
			delete_option( 'ssp_github_should_sleep' );
			delete_option( 'ssp_github_blob_start_time' );

			do_action( 'ssp_finished_github_blobs', $this->temp_dir );
		}

		return $done;
	}

	/**
	 * Get the folder path.
	 *
	 * @return string
	 */
	protected function get_folder_path() {
		$folder_path = $this->options->get( 'github_folder_path' );

		if ( ! $folder_path ) {
			return '';
		}

		return trailingslashit( $folder_path );
	}

	/**
	 * Process the page.
	 *
	 * @param Page $static_page Page object.
	 *
	 * @return void
	 */
	protected function process_page( $static_page ) {
		$filesystem         = \simply_static_pro\Helper::get_file_system();
		$database           = $this->get_database();
		$page_file_path     = $this->get_page_file_path( $static_page );
		$file_path          = Util::combine_path( $this->temp_dir, $page_file_path );
		$throttle_request   = apply_filters( 'ssp_throttle_github_request', false );
		$github_folder_path = $this->get_folder_path();

		// Throttling active?
		$options = get_option( 'simply-static' );

		if ( ! empty( $options['github_throttle_requests'] ) ) {
			$throttle_request = true;
		}

		if ( ! is_dir( $file_path ) && file_exists( $file_path ) ) {
			$content = $filesystem->get_contents( $file_path );

			// Prepare file for commit.
			$relative_path = str_replace( Util::normalize_slashes( $this->temp_dir ), $github_folder_path, $file_path );

			// Fixing possible empty spaces.
			$relative_path = str_replace( '//', '/', $relative_path );

			$blob = $database->create_blob( $file_path, $relative_path, $content );

			// Maybe throttle request.
			if ( $throttle_request ) {
				sleep( 1 );
			}

			if ( false !== $blob ) {
				$static_page->set_json_data_by_key( 'github', $blob );
			} else {
				return;
			}
		}
	}
}
