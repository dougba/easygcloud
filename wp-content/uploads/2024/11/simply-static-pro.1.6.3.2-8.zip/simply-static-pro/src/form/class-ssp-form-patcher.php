<?php

namespace simply_static_pro;

/**
 * Class to handle patches for various form plugins.
 */
class Form_Patcher {
	/**
	 * Contains instance or null
	 *
	 * @var object|null
	 */
	private static $instance = null;

	/**
	 * Returns instance of Form_Patcher.
	 *
	 * @return object
	 */
	public static function get_instance() {

		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Constructor for Form_Patcher.
	 */
	public function __construct() {
		add_action( 'ss_dom_before_save', array( $this, 'patch_form_html' ), 10, 2 );
	}

	/**
	 * Replace entire pages with iframe embeds.
	 *
	 * @param object $dom given DOM object.
	 * @param string $url given static URL.
	 *
	 * @return mixed
	 */
	public function patch_form_html( $dom, $url ) {
		// Fluent Forms compatibility.
		if ( is_plugin_active( 'fluentform/fluentform.php' ) ) {
			foreach ( $dom->find( '#fluent-form-submission-js-extra' ) as $element ) {
				$element->outertext = '';
			}
		}

		return $dom;
	}
}
